using UnityEngine;

public class Blue_Ball_Script : MonoBehaviour
{

    public float moveSpeed;
    public float jumpForce;
    public GameObject blueBall;
    public Rigidbody2D my_rb;
   

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Hello! This is the Blue Ball Scripts Start! :3 ");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            Debug.Log("Right Arrow Pressed!");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Debug.Log("Left Arrow Pressed!");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space))
        {
            Debug.Log("Up Arrow Pressed!");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

        }
    }
}
