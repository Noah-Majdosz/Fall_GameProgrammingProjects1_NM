using UnityEngine;

public class CameraFollowObject : MonoBehaviour {

	public Transform followObject; 			//this is going to be the transform of the 
											// GameObject we want to follow


	void FixedUpdate()						//FixedUpdate function
	{										// Begin FixedUpdate function
		
		Vector3 currentPosition = transform.position;   // We aren't allowed to just change a single component of a vector, so we need to 
														// store this object's current position in a temporary 
														// variable. This temporary variable is a Vector3 that we are calling "currentPosistion"
														// We taking the transform (a vector3) of this GameObject and 
														// storing those 3 values (x,y,z) in a new vector3 variable that we ARE allowed to edit

		currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f); //set get our current x position to the following:
        currentPosition.y = Mathf.Lerp(currentPosition.y, followObject.position.y, .5f); // Mathf.Lerp is a built-in math 		
                                                                                         // function in the Unity "Mathf" system in the engine. 
                                                                                         // 'Lerp' is short for 'linear interpolation'
                                                                                         // which is a linear function that finds a value at a point between 
                                                                                         // two other values. It's used to create smooth, linear movement.

        //  the first value is the current posistion of this GameObject

        currentPosition.z = -10;														//this is making sure to set the z posostion of 
																						// this GameObject (in this case, our camera) is -10. We don't want to change this.

		transform.position = currentPosition;											//now set our posistion to the "currentposistion" value 

	}
}


// ***************  THIS IS THE END OF OUR CODE  ************************


/*  *****KEY TERMS**********
// this GameObject  ---- the GameObject the script is attached to.
// v3 = Vector3 --- a set of 3 pieces of data (usually x,y,z points/coordinates, but not always)

*/
