using UnityEngine;

public class Pink_Ball_Script : MonoBehaviour
{

    public float moveSpeed;
    public float jumpForce;
    public GameObject pinkBall;
    public Rigidbody2D my_rb;
   

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Hello! This is the Green Ball Scripts Start! :3 ");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log("D Pressed!");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKey(KeyCode.A))
        {
            Debug.Log("A Pressed!");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.Space))
        {
            Debug.Log("W Pressed!");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

        }
    }
}
