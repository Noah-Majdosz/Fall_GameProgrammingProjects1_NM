using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;  //we need this 


public class SceneChangerScript : MonoBehaviour
{
 

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.R)) // if we press the R key
        {
            RestartGame(); //run our RestartGame function
        }

    }

    void RestartGame() //our custom RestartGame function
    {
        SceneManager.LoadScene(0); // use the scene manager to change to the 0 scene in our build index
    }
}
