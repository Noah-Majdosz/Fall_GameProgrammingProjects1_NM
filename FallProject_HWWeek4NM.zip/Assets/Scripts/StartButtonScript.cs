using UnityEngine;
using UnityEngine.SceneManagement;  //we need this 


public class StartButtonScript : MonoBehaviour // this is a script attached to our start button 
{                                              //Begin "StartButtonScript" Script

    void OnCollisionEnter2D(Collision2D other) // Built in Unity function telling the game to check for a collison
                                               // the (Collision2D other) portion is telling unity 
                                               // to see if we collided with another "other" thing 
                                               // but we will need to tell it what 'other' is
                                               // So we can read this line as 
                                               // "when some other object has collided with this object 
                                               // that this script is attached to..."
                        
    {                                           // THEN...
        if (other.gameObject.tag == "Player")   // if the tag on the game object is called "Player"
        {                                       //THEN...
            Debug.Log("collision detected");    // print a debug statement "collision detected" to the console and then
            ChangeScene();                       // run our "ChangeScene" function (starting on line ___)
        }                                        // END 'if other is player' if statement
    }                                            // END OnCollisionEnter2D function


    void ChangeScene()                          // this is a custom function (we are creating 
                                                // it start to finish) that will change our scene
    {                                           // begin ChangeScene function
        SceneManager.LoadScene(1);              // get the built in unity SceneManager and LoadScene #1. 
                                                // We define what number each scene is in 
                                                // our "build Profile" menu which can be found ____
    }                                           // END ChangeScene function
}                                               // END STARTBUTTONSCRIPT

   


// ************************** IGNORE BELOW **********************************
