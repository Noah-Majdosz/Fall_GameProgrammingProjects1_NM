using UnityEngine;

public class Jump_Timer : MonoBehaviour
{
    float timePassed = 0f;
    public float jumpForce;
    public Rigidbody2D my_rb;

    void Update()
    {
        timePassed += Time.deltaTime;  //This is the timer that counts the 5 seconds between jumps
        if (timePassed >= 4f)          //This if statment is when the timer reaches 4 sceonds it will call the jump function
        {
            //Debug.Log("Hump Actiivated");
            Jump();
            timePassed = 0f;
        }

    }
    void Jump()
    {
        //Debug.Log("Custom Function Activated");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse); //This is the line of code that makes the player jump 
    }
}
