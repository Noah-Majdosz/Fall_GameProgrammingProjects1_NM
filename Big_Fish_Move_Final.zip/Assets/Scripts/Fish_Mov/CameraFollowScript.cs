using UnityEngine;

public class CameraFollowObject : MonoBehaviour {

	public Transform followObject; 	


	void FixedUpdate()						
	{										
		Vector3 currentPosition = transform.position;  //gets the current position of the player
														

		currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f); //Changes the position of the camera
        currentPosition.y = Mathf.Lerp(currentPosition.y, followObject.position.y, .5f); //To match the postition of the player

        currentPosition.z = -10; 											

		transform.position = currentPosition; 
	}
}



