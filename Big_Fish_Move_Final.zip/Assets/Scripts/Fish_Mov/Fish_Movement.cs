using UnityEngine;

public class Fish_Movement: MonoBehaviour
{

    public float moveSpeed; //establises the movement speed of the player when the key is pressed
    public Rigidbody2D my_rb; //The rigid body that is moving with the player
   

    void Start()
    {
       // Debug.Log("Hello! This is the Fish Script starts! :3 ");
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
           // Debug.Log("Right Arrow Pressed!");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse); //gives the player the movement whne they
        }                                                                   //press the right arrow

        if (Input.GetKey(KeyCode.LeftArrow))
        {
           // Debug.Log("Left Arrow Pressed!");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse); //Moves the player when the left arrow is pressed
        }

    }

}
