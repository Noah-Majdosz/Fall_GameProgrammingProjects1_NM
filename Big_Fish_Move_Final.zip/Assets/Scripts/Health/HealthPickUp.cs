using UnityEngine;

public class HealthPickUp : MonoBehaviour
{

    [SerializeField] private float healthValue;

    private void OnTriggerEnter2D (Collider2D collision)
        {
            
        if (collision.tag == "Player")
        {
            collision.GetComponent<Health>().AddHealth(healthValue); // if player collides with the health pickup, it lets the health script know to heal 
            gameObject.SetActive(false); // if the paleyr picks up the health pickup, it makes it dissapear
        }

        }


}
