using UnityEngine;

public class Enemy_Damage : MonoBehaviour
{
    [SerializeField] private float damage;

    private void OnTriggerEnter2D(Collider2D collision) // This function makes the player take damage on collision with the "enemy"
    {
        if (collision.tag == "Player")
        {
            collision.GetComponent<Health>().TakeDamage(damage); // if the player collides with the enemy it tells the health script to activate the take damage function
        }
    }


}
