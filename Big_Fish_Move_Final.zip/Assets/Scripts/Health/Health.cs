using System;
using Unity.VectorGraphics;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    [SerializeField] private float startingHealth;
    public float currentHealth;
    public string sceneName;
    public bool ifdead;

    private void Awake()
    {
        currentHealth = startingHealth;  // when the script is loaded it sets the current health of the player to max
    }

    public void TakeDamage(float _damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - _damage, 0, startingHealth); //it checks what the current health is and lets the function know
        ifdead = true; //boolean varible to see if the player is dead or not

        if (currentHealth > 0 && ifdead == true)// checks if the player is alive and if not makes the boolean varible false
        {
         
        }
        else
        {
          ifdead = false;
        }

        if (ifdead != true || currentHealth < 0)// if the isdead boolean varible is false and the current health is 0, it loads the you died scene
        {
            SceneManager.LoadScene(sceneName);
        }
    }

    private void Update() // Function that if you press E, you take one damage for testing purposes
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            TakeDamage(1);
        }
    }

    public void AddHealth(float _value)// adds health to the player when picking up a health pickup
    {
        currentHealth = Mathf.Clamp(currentHealth + _value, 0, startingHealth);
    }
}

//Youtube video I used for Health,Healing and Damage https://youtu.be/yxzg8jswZ8A?si=fP_xXhnjx3wEHPil
