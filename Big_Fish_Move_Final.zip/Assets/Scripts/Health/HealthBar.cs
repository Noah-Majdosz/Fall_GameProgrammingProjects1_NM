using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    [SerializeField] private Health playerHealth;
    [SerializeField] private Image totalhealthBar;
    [SerializeField] private Image currenthealthBar;
    void Start()
    {
        totalhealthBar.fillAmount = playerHealth.currentHealth / 3; // Lets the game know that the health bar is at full health
    }

    
    void Update()
    {
        currenthealthBar.fillAmount = playerHealth.currentHealth / 3; // When damage is taken gets rid of one of the health states, by making some of the images not visable
    }
}
