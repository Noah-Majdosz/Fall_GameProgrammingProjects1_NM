using Unity.VisualScripting;
using UnityEngine;

public class Lever_Switch : MonoBehaviour
{
    public Sprite leverDown;
    public Sprite leverUp;
    public SpriteRenderer render;
    public GameObject myPrefab;
    public GameObject clone;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            render.sprite = leverDown; // when the player collides with the lever, it switches the sprite to the lever down 
            Vector2 spawnPosition = new Vector2(62.90019f, -44.06f); // gets the spawn point of the new cloned, sprite
            clone = Instantiate(myPrefab, spawnPosition, Quaternion.identity); // etsablishes what the clone should be and where it should be spawned
        }
        else
        {
            render.sprite = leverUp;// makes it so the sprite is always the right way up if nto interacted with by the player
        }
    }
}

//Link I used for help with the sprite changer https://stackoverflow.com/questions/55546025/how-to-switch-sprites-when-a-collision-occurs