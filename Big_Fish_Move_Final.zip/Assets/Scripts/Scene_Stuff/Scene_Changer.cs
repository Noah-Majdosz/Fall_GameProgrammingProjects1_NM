using UnityEngine;
using UnityEngine.SceneManagement;  


public class StartButtonScript : MonoBehaviour
{ 
    public int value;

    void OnCollisionEnter2D(Collision2D other)//Function for when the player collides with the object this is attached to, the desired scene is loaded   
    {
        
        SceneManager.LoadScene(value);     
                                                
    }                                           
}                                               
   
