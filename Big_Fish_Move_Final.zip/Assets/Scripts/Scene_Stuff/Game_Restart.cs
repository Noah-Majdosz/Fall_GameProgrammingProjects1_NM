using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement; 


public class SceneChangerScript : MonoBehaviour
{
    public string keySel;
    public KeyCode restartLevel;
    public int sceneNext;

    private void Start()
    {
        restartLevel = KeyCode.N; //etsablishes the keycode for restart level is n
    }
    void Update()
    {
        if (Input.GetKey(keySel)) // if the button established by the inspector is pressed, the game is restarted
        {
            RestartGame(); 
        }
        if (Input.GetKey(restartLevel))// if the restarted key is pressed, the level is restarted
        {
            SceneManager.LoadScene(sceneNext);
        }

    }

    void RestartGame() // function for restarting the entire game
    {
        SceneManager.LoadScene(0); 
    }
}
