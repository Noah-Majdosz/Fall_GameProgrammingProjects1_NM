using UnityEngine;
using UnityEngine.SceneManagement;

public class Main_Menu : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Hello! This is the Menu Script Starts! :3 ");
    }

    public void LoadScene(string sceneName)// fuction where when the button in the canvas is pressed, you are brought to the desired scene
    {
        SceneManager.LoadScene(sceneName);
    } 
    
}
